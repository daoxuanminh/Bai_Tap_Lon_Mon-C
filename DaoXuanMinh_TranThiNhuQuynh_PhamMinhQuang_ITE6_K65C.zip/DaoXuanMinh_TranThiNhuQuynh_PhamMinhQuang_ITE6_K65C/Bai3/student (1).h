#include<stdio.h>
struct student
{
    char name[40];
    int point;
};
